/***global.h******from Aho, Sethi, Ullman*************************************/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#define BSIZE 128
#define NONE -1
#define EOS '\0'

#define NUM 256
#define DIV 257
#define MOD 258
#define ID  259
#define DONE 260

#define  SYMMAX 100   /* size of symtable */

char yystring[1000];
int yylex();

int tokenval;    /* value of token atribute  */
int lineno;

typedef struct entry entry;
struct entry { /* form of symbol table entry */
  char *lexptr;
  int token;
  entry *next;
};
entry *symtable[SYMMAX]; /* symbol table */
entry *tokensym; /* use in place of tokenval for identifiers */

void error(char *m);
entry* lookup(char s[], int current_token);
void parse();
void expre();
void match(int t);

void parse();
void expr();
void term();
void factor();
void match(int t);

int lexan();
void emit(int t, int tval);
void init();
void exit(int n);
int main();

