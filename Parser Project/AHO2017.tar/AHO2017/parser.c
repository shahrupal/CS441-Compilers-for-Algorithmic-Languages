/*** parser.c  *****from Aho, Sethi, Ullman**************/

#include "global.h"

int lookahead;
void parse()   /*parses and translates expression list  */
{
	lookahead = yylex(); /* was lookahead = laxan() */
	while(lookahead != DONE) {
		expr(); match(';');
	}
}

/*
E -> TE'
 parse_E(){
   parse_term();
   Parse_E'();
}


E'-> +TE' | epsilon
 parse_E'() {
   if (lookahead == '+') {
       match('+');
       parse_T();
       parse_E'();
      }
   else
    if (lookahead == '+') {
       match('+');
       parse_T();
       parse_E'();
     }
   else error("unexpected token");
 }

The resulting code is a result of:
  -  removing the tail recursion from parse_E'()
  -  inlining the modified parse_E'() in parse_E().

*/
void expr()
{
	int t;
	term();
	while(1)
		switch (lookahead) {
		case '+': case '-':
			t=lookahead;
			match(lookahead); term(); emit(t, NONE);
			continue;
		default:
			return;
	}
}

/*
 T  -> FT'
 T' -> *FT' | epsilon 
 Similar steps: remove recursion, inline
*/
void term()
{
	int t;
	factor();
	while(1)
		switch(lookahead) {
		case '*': case '/' : case DIV: case MOD:
			t=lookahead;
			match(lookahead); factor(); emit (t, NONE);
			continue;
		default:
			return;
		}
}

/*
 F -> ( E ) | ID | NUM
*/
void factor()
{
		switch(lookahead) {
			case '(':
				match('('); expr(); match(')'); break;
			case NUM:
				emit(NUM, tokenval); match(NUM); break;
			case ID:
				emit(ID, tokenval); match(ID); break;
			default:
				error("syntax error");
	}
}

void match(t)
	int t;
{
	if (lookahead == t)
		lookahead = yylex();
	else error("syntax error - unexpected token");
}

